-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 16, 2024 at 10:38 AM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bgt`
--

-- --------------------------------------------------------

--
-- Table structure for table `auditor`
--

DROP TABLE IF EXISTS `auditor`;
CREATE TABLE IF NOT EXISTS `auditor` (
  `audID` int NOT NULL AUTO_INCREMENT,
  `aname` text NOT NULL,
  `phnum` bigint NOT NULL,
  `pwd` text NOT NULL,
  PRIMARY KEY (`audID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `auditor`
--

INSERT INTO `auditor` (`audID`, `aname`, `phnum`, `pwd`) VALUES
(1, 'ssssss', 23456, 'f27f6f1c7c5cbf4e3e192e0a47b85300'),
(2, 'sss', 9999999999, '9f6e6800cfae7749eb6c486619254b9c'),
(3, 'ddd', 4444444444, '77963b7a931377ad4ab5ad6a9cd718aa'),
(4, 'fff', 4444444444, '343d9040a671c45832ee5381860e2996'),
(5, 'fff', 5555555555, '343d9040a671c45832ee5381860e2996'),
(6, 'hhh', 9999999999, 'a3aca2964e72000eea4c56cb341002a4'),
(7, 'Sathish', 9110227725, '9f6e6800cfae7749eb6c486619254b9c'),
(8, 'ssss', 77777777777, '8f60c8102d29fcd525162d02eed4566b'),
(9, 'ssss', 5555555555, '8f60c8102d29fcd525162d02eed4566b'),
(10, 'sss', 4444444444, '9f6e6800cfae7749eb6c486619254b9c');

-- --------------------------------------------------------

--
-- Table structure for table `audits`
--

DROP TABLE IF EXISTS `audits`;
CREATE TABLE IF NOT EXISTS `audits` (
  `audID` int NOT NULL,
  `expID` int NOT NULL,
  `remarks` text NOT NULL,
  `adt` datetime NOT NULL,
  PRIMARY KEY (`audID`,`expID`),
  KEY `expID` (`expID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `audits`
--

INSERT INTO `audits` (`audID`, `expID`, `remarks`, `adt`) VALUES
(2, 1, 'correct', '2024-03-16 00:57:00'),
(2, 2, 'correct', '2024-03-16 00:58:00');

-- --------------------------------------------------------

--
-- Table structure for table `budget`
--

DROP TABLE IF EXISTS `budget`;
CREATE TABLE IF NOT EXISTS `budget` (
  `budgetID` int NOT NULL AUTO_INCREMENT,
  `head` text NOT NULL,
  `amnt_san` int NOT NULL,
  `dateofsan` date NOT NULL,
  `deptID` int NOT NULL,
  `empID` int NOT NULL,
  PRIMARY KEY (`budgetID`),
  KEY `deptID` (`deptID`),
  KEY `empID` (`empID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `budget`
--

INSERT INTO `budget` (`budgetID`, `head`, `amnt_san`, `dateofsan`, `deptID`, `empID`) VALUES
(1, 'sssss', 222222, '2024-02-28', 1, 1),
(2, 'sssss', 222222, '2024-02-28', 2, 1),
(3, 'ffffff', 300000, '2024-03-06', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `deptID` int NOT NULL AUTO_INCREMENT,
  `dname` text NOT NULL,
  `location` text NOT NULL,
  `pwd` text NOT NULL,
  PRIMARY KEY (`deptID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`deptID`, `dname`, `location`, `pwd`) VALUES
(1, 'AIML', 'Library Block', '9f6e6800cfae7749eb6c486619254b9c'),
(2, 'CS', 'cs block', '77963b7a931377ad4ab5ad6a9cd718aa'),
(3, 'CSE', 'CSE Block', '271226cb355bdda491d38bfaf40f675d'),
(4, 'CSE', 'cs block', 'fcd0c398ba3c9bc0dbd90153ddb6d637'),
(5, 'ECE', 'ECE block', '411a9a1b1519ebd6c96cd25a5b2ecdd5'),
(6, 'AIML', 'Library Block', '73bc904b7a02e205b5e46ef6245fa7a3');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `empID` int NOT NULL AUTO_INCREMENT,
  `ename` text NOT NULL,
  `position` text NOT NULL,
  `deptID` int NOT NULL,
  PRIMARY KEY (`empID`),
  KEY `deptID` (`deptID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`empID`, `ename`, `position`, `deptID`) VALUES
(1, 'shabarish', 'Manager', 1),
(2, 'Abhishek', 'manager', 2),
(3, 'saishri', 'sweeper', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

DROP TABLE IF EXISTS `expense`;
CREATE TABLE IF NOT EXISTS `expense` (
  `expID` int NOT NULL AUTO_INCREMENT,
  `edate` date NOT NULL,
  `purpose` text NOT NULL,
  `amount` int NOT NULL,
  `budgetID` int NOT NULL,
  PRIMARY KEY (`expID`),
  KEY `budgetID` (`budgetID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`expID`, `edate`, `purpose`, `amount`, `budgetID`) VALUES
(1, '2024-02-01', 'fghj', 12, 1),
(2, '2024-02-21', 'dwefr', 12345, 2);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audits`
--
ALTER TABLE `audits`
  ADD CONSTRAINT `audits_ibfk_1` FOREIGN KEY (`expID`) REFERENCES `expense` (`expID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `budget`
--
ALTER TABLE `budget`
  ADD CONSTRAINT `budget_ibfk_1` FOREIGN KEY (`deptID`) REFERENCES `department` (`deptID`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `budget_ibfk_2` FOREIGN KEY (`empID`) REFERENCES `employee` (`empID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`deptID`) REFERENCES `department` (`deptID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `expense`
--
ALTER TABLE `expense`
  ADD CONSTRAINT `expense_ibfk_1` FOREIGN KEY (`budgetID`) REFERENCES `budget` (`budgetID`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
